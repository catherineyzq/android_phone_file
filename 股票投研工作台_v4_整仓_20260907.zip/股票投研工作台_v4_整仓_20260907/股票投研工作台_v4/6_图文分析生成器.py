#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图文分析生成器 v0.1 ｜ 给三池(候选/变体/反包)每只票生成图文 HTML 卡
============================================================
用法：
  python3 6_图文分析生成器.py [日期] --pool main        候选池(读 候选池_*.md)
  python3 6_图文分析生成器.py [日期] --pool longshadow  变体池(读 变体池_*.md)
  python3 6_图文分析生成器.py [日期] --pool fanbao      反包池(读 反包池_*.md)

每张卡 = 迷你K线(红涨绿跌+量柱) + 关键位黄虚线 + 现价/铁损 + 池内标签。
输出：每日记录/YYYY-MM-DD/图文池_<池名>_<日期>.html
数据源：新浪K线。仅供研究参考，不构成投资建议。

色带(zones)约定（v0.2 起，图例见每份 HTML 顶部）：
  候选池 main：
    绿带 = [实体底, 涨停后高点] 伏击区——回踩不破实体底(黄线)可分批；放量收复带顶=转强确认
    红带 = [60日最低, 铁损] 破位离场区——收盘跌破铁损(红线)无条件走
  变体池 longshadow：
    绿带 = [止损, 攻击位] 运行区——缩量企稳后放量突破攻击位(黄线)才是买点
    红带 = [60日最低, 止损] 破止损离场区
  反包池 fanbao：无带（按天计卖、不预判区间）
  两边界全部读池 md 现成列（实体底/铁止损、涨停后高点、试盘高点、止损…），
  生成器只读不重算 → 图上数字与池表永远一致。
"""
import argparse
import datetime as dt
import json
import os
import re
import sys
import time

import requests

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")
HDR_SINA = {"User-Agent": UA, "Referer": "https://finance.sina.com.cn"}
S = requests.Session()
S.headers.update({"User-Agent": UA})
SINA_KLINE = "https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ARCHIVE_ROOT = os.path.join(SCRIPT_DIR, "每日记录")

RED = "#e23b3b"    # 涨(中国红)
GREEN = "#0aa858"  # 跌(绿)
YELLOW = "#f2c200"  # 黄虚线(关键位)


def log(m):
    print(m, flush=True)


def sina_symbol(code):
    if code.startswith(("60", "68", "9")):
        return "sh" + code
    if code.startswith(("00", "30", "20")):
        return "sz" + code
    return "bj" + code


def fetch_kline(code, n=90):
    try:
        r = S.get(SINA_KLINE, params={
            "symbol": sina_symbol(code), "scale": 240, "ma": "no", "datalen": n,
        }, headers=HDR_SINA, timeout=12)
        data = json.loads(r.text)
    except Exception:
        return []
    out = []
    for b in data:
        try:
            out.append({
                "day": str(b["day"])[5:].replace("-", "/"),
                "open": float(b["open"]), "high": float(b["high"]),
                "low": float(b["low"]), "close": float(b["close"]),
                "volume": float(b["volume"]),
            })
        except (KeyError, TypeError, ValueError):
            continue
    return out


# ---------------------------------------------------------------- K线 SVG
def kline_svg(code, bars, lines=None, mark_days=None, zones=None, w=360, h=150):
    """lines: [{"label":str,"v":float,"color":str,"dash":bool}]
    mark_days: {index: label} 高亮标注事件日(横跨K线区)
    zones: [{"lo":低价(下沿),"hi":高价(上沿),"color":str}] 画半透明区域带
    返回 svg 字符串（K线 + 底部量柱）。"""
    if len(bars) < 30:
        bars = bars
    n = len(bars)
    mh = 26                     # 量柱区高
    kh = h - mh - 14
    pad_l, pad_r = 8, 58
    cw = (w - pad_l - pad_r) / max(n, 1)
    body_w = max(1.6, cw * 0.62)

    hi = max(b["high"] for b in bars)
    lo = min(b["low"] for b in bars)
    span = (hi - lo) or 1
    hi += span * 0.06
    lo -= span * 0.06
    span = hi - lo
    vmax = max(b["volume"] for b in bars) or 1

    def px(i): return pad_l + i * cw + cw / 2
    def py(v): return 4 + (hi - v) / span * kh

    s = []
    s.append(f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
             f'style="width:100%;height:auto;display:block">')
    # 网格
    for g in range(5):
        gy = 4 + kh * g / 4
        s.append(f'<line x1="{pad_l}" y1="{gy:.1f}" x2="{w - pad_r}" y2="{gy:.1f}" '
                 f'stroke="#eee" stroke-width="0.5"/>')
    # 区域带（入场/离场范围，画在 K 线下层，半透明不遮线）
    for z in (zones or []):
        try:
            z_lo, z_hi = float(z["lo"]), float(z["hi"])
        except (TypeError, ValueError, KeyError):
            continue
        if z_hi <= z_lo:
            continue
        lo_v = max(z_lo, lo)          # 带下沿价（图上偏下）
        hi_v = min(z_hi, hi)          # 带上沿价（图上偏上）
        if lo_v >= hi_v:
            continue
        ya = py(hi_v)
        yb = py(lo_v)
        s.append(f'<rect x="{pad_l}" y="{ya:.1f}" width="{w - pad_l - pad_r:.1f}" '
                 f'height="{yb - ya:.1f}" fill="{z.get("color", "#2e9e43")}" '
                 f'opacity="0.13"/>')
    # K线
    for i, b in enumerate(bars):
        x = px(i)
        up = b["close"] >= b["open"]
        col = RED if up else GREEN
        # 影线
        s.append(f'<line x1="{x:.1f}" y1="{py(b["high"]):.1f}" x2="{x:.1f}" '
                 f'y2="{py(b["low"]):.1f}" stroke="{col}" stroke-width="1"/>')
        # 实体
        yo = py(b["open"])
        yc = py(b["close"])
        y1, y2 = min(yo, yc), max(yo, yc)
        if y2 - y1 < 1:
            y2 = y1 + 1
        s.append(f'<rect x="{x - body_w / 2:.1f}" y="{y1:.1f}" width="{body_w:.1f}" '
                 f'height="{y2 - y1:.1f}" fill="{col}"/>')
    # 关键位虚线 + 右侧标签（独立槽位防重叠，标签右缘对齐）
    tags = []
    for ln in (lines or []):
        v = ln["v"]
        if not v or not (lo <= v <= hi):
            continue
        tags.append((py(v), ln))
    tags.sort(key=lambda t: t[0])
    slot_y, used = [], set()
    slot_step = 11
    for y, ln in tags:
        # 就近找空闲槽，避免标签文字互相压叠
        chosen = None
        for dy in (0, -1, 1, -2, 2, -3, 3):
            cand = round(y / slot_step) * slot_step + dy * slot_step
            if cand < 0 or cand in used:
                continue
            # 槽位中心尽量接近线位置
            chosen = cand
            break
        if chosen is None:
            chosen = round(y / slot_step) * slot_step
        used.add(chosen)
        dash = ' stroke-dasharray="5,4"' if ln.get("dash", True) else ""
        s.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{w - pad_r}" y2="{y:.1f}" '
                 f'stroke="{ln.get("color", YELLOW)}" stroke-width="1.2"{dash}/>')
        # 短线把小标签接到对应槽位（同色）
        ty = chosen
        if abs(ty - y) > 2.5:
            s.append(f'<line x1="{w - pad_r + 1}" y1="{y:.1f}" x2="{w - pad_r + 1}" '
                     f'y2="{ty:.1f}" stroke="{ln.get("color", YELLOW)}" stroke-width="1"/>')
        s.append(f'<text x="{w - pad_r + 5}" y="{ty + 3:.1f}" font-size="9" '
                 f'fill="{ln.get("color", YELLOW)}">{ln.get("label", "")}</text>')
    # 事件标注(顶部三角+标签)
    for i, label in (mark_days or {}).items():
        if not (0 <= i < n):
            continue
        x = px(i)
        s.append(f'<path d="M{x:.1f},{4} l-4,8 l8,0 z" fill="#7a5cff"/>')
        s.append(f'<text x="{x:.1f}" y="2" font-size="8.5" fill="#7a5cff" '
                 f'text-anchor="middle">{label}</text>')
    # 量柱
    for i, b in enumerate(bars):
        x = px(i)
        vh = b["volume"] / vmax * (mh - 8)
        up = b["close"] >= b["open"]
        col = RED if up else GREEN
        s.append(f'<rect x="{x - body_w / 2:.1f}" y="{h - mh + (mh - 8) - vh + 4:.1f}" '
                 f'width="{body_w:.1f}" height="{vh:.1f}" fill="{col}" opacity="0.55"/>')
    # 末端日期
    if n:
        s.append(f'<text x="{pad_l}" y="{h - 2}" font-size="8" fill="#aaa">'
                 f'{bars[0]["day"]} ~ {bars[-1]["day"]}</text>')
    s.append("</svg>")
    return "".join(s)


# ---------------------------------------------------------------- 卡装配
def card_html(code, name, meta, bars, lines, mark_days=None, tag="", hint="", zones=None):
    n = len(bars)
    # 事件日索引（相对K线末尾）
    md = {}
    for lbl, day in (mark_days or {}).items():
        for i in range(max(0, n - 60), n):
            if bars[i]["day"] == day:
                md[i] = lbl
                break
    svg = kline_svg(code, bars[-60:], lines=lines, mark_days=md, zones=zones)
    price = meta.get("price", "")
    extra = " · ".join(f"{k}:{v}" for k, v in meta.items() if k != "price")
    hint_html = ""
    if hint:
        hint_html = ('<div style="margin-top:7px;padding:7px 9px;background:#fff8e6;'
                     'border:1px solid #f2dfa7;border-radius:7px;font-size:11.5px;'
                     'line-height:1.55;color:#5a4a1a">'
                     '<b style="color:#8a6d00">📌 操作提示</b><br>' + hint + '</div>')
    return f"""
<div style="border:1px solid #e3e3e3;border-radius:10px;padding:10px;margin:8px;
            background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.06);break-inside:avoid">
  <div style="display:flex;justify-content:space-between;align-items:baseline">
    <b style="font-size:15px">{code} {name}</b>
    <span style="color:{RED};font-weight:700">{tag}</span>
  </div>
  <div style="font-size:11px;color:#666;margin:2px 0 6px">{extra}</div>
  {svg}
  {hint_html}
</div>"""


def vol_trend_txt(bars, n=5):
    """量能趋势：近n日均量 vs 前n日均量 → (文字, 缩量?)"""
    if len(bars) < 2 * n:
        return "", None
    vols = [float(b["volume"]) for b in bars]
    cur = sum(vols[-n:]) / n
    prev = sum(vols[-2 * n:-n]) / n
    if prev <= 0:
        return "", None
    r = cur / prev
    if r <= 0.7:
        return f"近期量能 5日均量较前段 <b>缩量 {r:.2f}×</b>（没人卖，洗盘特征）", r
    if r >= 1.3:
        return f"近期量能 5日均量较前段 <b>放量 {r:.2f}×</b>（资金活跃，注意承接）", r
    return f"量能平缓（前后段 5日均量比 {r:.2f}）", r


def build_main_hint(row, bars):
    """候选池卡的提示：位置待遇 + 量价 + 何时入手 + 止损"""
    try:
        eb, iron = [float(x) for x in row["实体底/铁止损"].split("/")]
        post_hi = float(row.get("涨停后高点", "0") or 0)
        dd = float(str(row.get("高点回撤", "0")).rstrip("%"))
    except (ValueError, KeyError):
        eb = iron = post_hi = dd = 0
    state = row.get("状态", "△")
    close = bars[-1]["close"] if bars else 0
    vol_txt, vol_r = vol_trend_txt(bars)
    # 位置待遇
    if state == "✓":
        pos_txt = "年线上 · 趋势健康，可正常做（分水岭上方）"
    elif state == "△":
        pos_txt = "分水岭下 · <b>抢反弹待遇：仓位减半/只做A/到年线先减</b>"
    else:
        pos_txt = state
    # 距实体底/铁损空间
    gap_eb = f"{(close - eb) / eb * 100:+.1f}%" if eb else "--"
    # 入手话术（候选池≠买入池）
    if dd and 2 <= dd <= 8:
        buy = (f"回撤 {dd:.1f}%（最佳区）。<b>买点=缩量企稳</b>（回踩不破实体底 {eb:.2f}）"
               f"+ <b>放量收复</b>（站上 {post_hi:.2f} 前高）再分批；<b>别在下跌中接刀</b>")
    elif dd:
        buy = (f"回撤 {dd:.1f}% 偏深。<b>先等缩量企稳</b>（现价距实体底 {eb:.2f} 仅 {gap_eb}），"
               f"放量收复 {post_hi:.2f} 才谈上车，不抢跑")
    else:
        buy = f"等缩量企稳于实体底 {eb:.2f} + 放量收复前高再动手"
    stop = f"铁损 {iron:.2f}，<b>收盘破位无条件走</b>；15日不启动也走"
    return f"{pos_txt}<br>{vol_txt}<br><b>买入：</b>{buy}<br><b>止损：</b>{stop}"


# ---------------------------------------------------------------- 池文件解析
def parse_pool_md(path):
    """列名驱动解析 + 记录所属小节(##/### 标题)：
    返回 [{col_name: cell, '_sec': '强试盘/普通试盘/A级/…'}]，支持一文件多张表。"""
    rows = []
    header = []
    sec = ""
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line.startswith("## ") or line.startswith("### "):
            t = line.lstrip("# ").strip()
            # 简化小节名：去掉括号说明与序号
            sec = t.split("（")[0].replace("① ", "").replace("② ", "")
            continue
        if not line.startswith("|") or "---" in line:
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if cells and cells[0] == "代码":
            header = cells
            continue
        if not header or not cells or not re.fullmatch(r"\d{6}", cells[0] or ""):
            continue
        row = dict(zip(header, cells))
        row["_sec"] = sec
        rows.append(row)
    return rows


# ---------------------------------------------------------------- 生成
def gen(date_s, pool):
    out_dir = os.path.join(ARCHIVE_ROOT, date_s[:4] + "-" + date_s[4:6] + "-" + date_s[6:])
    pool_cn = {"main": "候选池", "longshadow": "变体池", "fanbao": "反包池"}[pool]
    md_path = os.path.join(out_dir, f"{pool_cn}_{date_s}.md")
    if not os.path.exists(md_path):
        log(f"[x] 找不到 {md_path}")
        sys.exit(1)
    rows = parse_pool_md(md_path)
    log(f"[i] {pool_cn} 解析到 {len(rows)} 行表行")

    cards = []
    for i, row in enumerate(rows, 1):
        code, name = row["代码"], row["名称"]

        def num(col):
            v = row.get(col, "")
            try:
                return float(str(v).rstrip("%"))
            except Exception:
                return None

        bars = fetch_kline(code)
        if len(bars) < 30:
            log(f"[w] {code} K线不足，跳过")
            continue
        # 类型标签：主池=A级/B级/C级/D级；变体池=强试盘/普通试盘/洗盘完成；反包池=三类
        last = bars[-1]["close"]
        tag = row.get("_sec", "").strip()
        if pool == "main" and "级" in tag:
            tag = tag.replace("（", " ").replace("）", "")
        elif pool == "longshadow":
            if "强试盘" in tag:
                tag = "🔥 强试盘"
            elif "洗盘完成" in tag:
                tag = "✅ 洗盘完成"
            elif tag:
                tag = "普通试盘"
            else:
                tag = row.get("状态", "")
        elif pool == "fanbao":
            # v4：反包子类标到 html 卡顶(原留空丢类型)
            tag=(tag or "").replace("（"," ").replace("）","").replace("2只","").replace("1只","").replace("5只","").strip()
        else:
            tag = row.get("状态", tag)
        lines, md, zones = [], [], []
        meta = {k: v for k, v in row.items() if k not in ("代码", "名称", "实体底/铁止损",
                "涨停后高点", "高点回撤", "状态", "试盘高点", "关键位(开/收)", "止损(试盘低)",
                "试盘高点(压力)", "试盘低点(止损)", "今日缩量", "事件", "_sec") and v}
        meta.setdefault("现价", last)

        def add_line(label, col, color, dash=True):
            v = num(col)
            if v:
                lines.append({"label": label, "v": v, "color": color, "dash": dash})

        if pool == "main":
            # 实体底/铁损 → 黄虚线+红虚线；涨停日标注
            eb_iron = row.get("实体底/铁止损", "")
            eb = iron = None
            if "/" in eb_iron:
                eb, iron = eb_iron.split("/")
                for lbl, v, c in (("实体底", eb, YELLOW), ("铁损", iron, RED)):
                    try:
                        lines.append({"label": lbl, "v": float(v), "color": c})
                    except ValueError:
                        pass
            lines.append({"label": "现", "v": last, "color": "#2b6de8", "dash": False})
            if row.get("涨停日"):
                md = {"涨停": row["涨停日"]}
            # 区域带：绿=伏击区(实体底~涨停后高点)；红=破铁损离场区
            try:
                eb_v, iron_v = float(eb), float(iron)
                hi_pt = num("涨停后高点") or max(last, eb_v * 1.03)
                if hi_pt and hi_pt > eb_v:
                    zones.append({"lo": eb_v, "hi": hi_pt, "color": "#2e9e43"})
                lo60 = min(b["low"] for b in bars[-60:])
                if iron_v > lo60:
                    zones.append({"lo": lo60, "hi": iron_v, "color": "#e23b3b"})
            except (TypeError, ValueError):
                pass
        elif pool == "longshadow":
            # 试盘高点→黄虚线(攻击位)；止损列→红虚线；现价蓝
            add_line("攻击位", "试盘高点", YELLOW)
            add_line("止损", "止损(试盘低)", RED)
            add_line("止损", "试盘低点(止损)", RED)
            lines.append({"label": "现", "v": last, "color": "#2b6de8", "dash": False})
            if row.get("试盘日"):
                md = {"试盘": row["试盘日"]}
            # 区域带：绿=运行区(止损~攻击位)；红=破止损离场区
            atk = num("试盘高点") or num("试盘高点(压力)")
            stop = num("止损(试盘低)") or num("试盘低点(止损)")
            if stop and atk and atk > stop:
                zones.append({"lo": stop, "hi": atk, "color": "#2e9e43"})
            if stop:
                lo60 = min(b["low"] for b in bars[-60:])
                if stop > lo60:
                    zones.append({"lo": lo60, "hi": stop, "color": "#e23b3b"})
        else:  # fanbao：现价蓝线
            lines.append({"label": "现", "v": last, "color": "#2b6de8", "dash": False})

        hint = build_main_hint(row, bars) if pool == "main" else ""
        cards.append(card_html(code, name, meta, bars, lines, md, tag, hint=hint, zones=zones))
        if i % 20 == 0:
            log(f"  …{i}/{len(rows)}")

    if pool == "main":
        legend = ('<span style="color:#2e9e43">■</span> <b>绿带=伏击区</b>(实体底~涨停后高点)　'
                  '<span style="color:#e23b3b">■</span> <b>红带=破铁损离场</b><br>'
                  '<span style="color:#777">读法：现价在绿带内 → 回踩不破实体底(黄虚线)可分批接；'
                  '放量站上带顶(涨停后高点)=转强确认再跟。'
                  '收盘跌破铁损(红虚线)无条件走。蓝线=现价。色带区间来自池表数据，图文始终一致。</span>')
    elif pool == "longshadow":
        legend = ('<span style="color:#2e9e43">■</span> <b>绿带=运行区</b>(止损~攻击位)　'
                  '<span style="color:#e23b3b">■</span> <b>红带=破止损离场</b><br>'
                  '<span style="color:#777">读法：绿带内洗盘，缩量企稳后可观察；'
                  '放量突破攻击位(黄虚线)=买点。跌破止损(红虚线)离场。蓝线=现价。</span>')
    else:
        legend = "仅供研究参考，不构成投资建议"

    html = f"""<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8">
<title>图文池 · {pool_cn} · {date_s}</title>
<style>
body{{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;
     background:#f6f7f9;margin:0;padding:14px;}}
h1{{font-size:18px;margin:4px 8px}}
.sub{{font-size:12px;color:#888;margin:2px 8px 10px}}
.legend{{font-size:12px;color:#444;margin:0 8px 10px;padding:7px 10px;
        background:#fff;border:1px solid #e3e3e3;border-radius:8px}}
.wrap{{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));
      gap:4px;align-items:start}}
</style></head><body>
<h1>📊 图文池 · {pool_cn} · {date_s}</h1>
<div class="sub">红涨绿跌 · 黄虚线=关键位 · 蓝线=现价</div>
<div class="legend">{legend}</div>
<div class="wrap">{''.join(cards)}</div>
</body></html>"""
    out = os.path.join(out_dir, f"图文池_{pool_cn}_{date_s}.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    log(f"[✓] 已写出 {out}（{len(cards)} 张卡）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("date", nargs="?", default=None)
    ap.add_argument("--pool", default="main", choices=["main", "longshadow", "fanbao"])
    args = ap.parse_args()
    date_s = args.date or dt.date.today().strftime("%Y%m%d")
    gen(date_s, args.pool)


if __name__ == "__main__":
    main()
